#include <stdio.h> 
#include <string.h> 
#include "fonction.h"

#include <errno.h>
#include <stdlib.h>
#include <stdbool.h>
#include "callbacks.h"
#include <gtk/gtk.h>

void ajout(char nom_fich[], Produit p)
{FILE *f=NULL;
f=fopen(nom_fich,"a");
if(f!=NULL)
 {
  fprintf(f,"%s %s %s %s %d %d %.2f \n",p.reference,p.libelle,p.type,p.date_exp,p.qte,p.sortie,p.prix); 
  fclose(f);
 }
}

Produit recherche(char nom_fich[],char ref[])
{FILE *f=NULL;
Produit p;
f=fopen(nom_fich,"r");
if(f!=NULL)
{
   while(fscanf(f,"%s %s %s %s %d %d %f \n",p.reference,p.libelle,p.type,p.date_exp,&p.qte,&p.sortie,&p.prix)!=EOF)
      if(strcmp(p.reference,ref)==0)
         {fclose(f);
          return(p);}
}
}

void supprimer(char nom_fich[],char ref[])
{FILE *f=NULL;
FILE *f2=NULL;
Produit e;

f=fopen(nom_fich,"r");
f2=fopen("produit2.txt","w");
if(f!=NULL)
  while(fscanf(f,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,&e.qte,&e.sortie,&e.prix)!=EOF)
      if(strcmp(e.reference,ref)!=0)
         fprintf(f2,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,e.qte,e.sortie,e.prix);
fclose(f);
fclose(f2);
remove(nom_fich); 
rename("produit2.txt",nom_fich);
}

void modif(char nom_fich[],Produit p)
{FILE *f=NULL;
FILE *f2=NULL;
Produit e;

f=fopen(nom_fich,"r");
f2=fopen("produit2.txt","w");
if(f!=NULL)
  {while(fscanf(f,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,&e.qte,&e.sortie,&e.prix)!=EOF)
      if(strcmp(e.reference,p.reference)==0)
         fprintf(f2,"%s %s %s %s %d %d %f \n",p.reference,p.libelle,p.type,p.date_exp,p.qte,p.sortie,p.prix);
      else
         fprintf(f2,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,e.qte,e.sortie,e.prix);
   fclose(f);
   fclose(f2);
   remove(nom_fich); 
   rename("produit2.txt",nom_fich);
   }
}

void repture_stock(char nom_fich[])
{FILE *f=NULL;
 FILE *f2=NULL;
Produit e;

f=fopen(nom_fich,"r");
f2=fopen("repture.txt","w");
if(f!=NULL)
  {while(fscanf(f,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,&e.qte,&e.sortie,&e.prix)!=EOF)
      if(e.qte==0)
         fprintf(f2,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,e.qte,e.sortie,e.prix);
   fclose(f);
   fclose(f2);
  }
}

enum{ 
REF,
LIB,
TYPE,
DATE,
QTE,
SORTIE,
PRIX,
COLUMNS
};

void affiche(GtkWidget *liste,char nom_fich[])
{Produit e;
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
char ch1[10],ch2[10],ch3[10];
FILE *f;

store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Reference",renderer,"text",REF,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);
	
	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Libelle",renderer,"text",LIB,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Type",renderer,"text",TYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_resizable(column,TRUE);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Date expiration",renderer,"text",DATE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Quantite",renderer,"text",QTE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Quantite sortie",renderer,"text",SORTIE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);

	renderer=gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("Prix",renderer,"text",PRIX,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste), column);
	gtk_tree_view_column_set_expand(column,TRUE);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING);
f=fopen(nom_fich,"r");
if(f!=NULL)

{ f = fopen(nom_fich,"a+");
		while(fscanf(f,"%s %s %s %s %d %d %f \n",e.reference,e.libelle,e.type,e.date_exp,&e.qte,&e.sortie,&e.prix)!=EOF)
	{sprintf(ch1,"%d",e.qte);
	sprintf(ch2,"%d",e.sortie);
	sprintf(ch3,"%.2f",e.prix);
	
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,REF,e.reference,LIB,e.libelle,TYPE,e.type,DATE,e.date_exp,QTE,ch1,SORTIE,ch2,PRIX,ch3,-1);
	}
	fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
gtk_tree_view_set_enable_search(GTK_TREE_VIEW(liste),TRUE);
}
