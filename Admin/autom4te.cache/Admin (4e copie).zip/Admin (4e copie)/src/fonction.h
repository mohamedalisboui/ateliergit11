#include <gtk/gtk.h>

typedef struct 
{
char username[50];
char password[50];
}user;

typedef struct 
{
char jour [5];
char heure [5];
char  etage [5];
char eau[5];
}debit;

void resultat (int choix[], debit d);

void tester_debit (debit d ,char txt[100]);

void ajouter_user ( user u , char nomf[]);
void ajouter_admin ( user a , char nomf[]);
void afficher_users(GtkTreeView *liste);
void supprimer (user u , char nomf[]);

int verifier_username ( user u , char nomf[]);
int verifier_admin ( user a , char nomf[]);
void modifier_user (user u , char nomf[]);
void modifier_pw (user u , char nomf[]);
