#include <gtk/gtk.h>



void
on_retour_aff_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_saveEdit_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reMod_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_reAj_clicked                        (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_delete_clicked                      (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_reSupp_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toAdd_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toEdit_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toDel_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toAff_clicked                       (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_toNumber_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_af_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_check_id_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_re_Nombre_clicked                   (GtkWidget       *objet,
                                        gpointer         user_data);
