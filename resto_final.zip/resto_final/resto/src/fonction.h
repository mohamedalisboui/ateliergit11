#ifndef FONCTION_H_
#define FONCTION_H_
#include <gtk/gtk.h>

struct produit{
char reference[10];
char libelle[30];
char type[15];
char date_exp[11];
int qte;
int sortie;
float prix;
};typedef struct produit Produit;

void ajout(char nom_fich[], Produit p);
Produit recherche(char nom_fich[],char ref[]);
void supprimer(char nom_fich[],char ref[]);
void modif(char nom_fich[],Produit p);
void repture_stock(char nom_fich[]);
void affiche(GtkWidget *liste ,char nom_fich[]);
 #endif
