#include <gtk/gtk.h>


void
on_button_suser_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);;

void
on_button_signup_suser_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_admin_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button7_login_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button8_login_clicked               (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button9_signup_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button12_supprimer_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button13_chercher_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);


void
on_button11_modif_clicked              (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button10_ajouter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_button14_ajouter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button15_username_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button16_pw_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button18_modifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button19_modifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_modifier_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button21_supprimer_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button22_id_clicked                 (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button23_username_clicked           (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_signup_admin_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button2_signup_admin_clicked        (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton4_agent2_clicked         (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
void
on_checkbutton3_nut_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton1_agent_clicked          (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_checkbutton2_technicien_clicked     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button1_role_clicked                (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_pred_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_button3_afficher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button5_afficher_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button6_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button1_confirmer_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button_affichage_clicked            (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_button1_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_retour_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton4_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton2_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton3_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton3_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton4_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button1_suivant_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_chercher_clicked            (GtkButton       *button,
                                        gpointer         user_data);



void
on_3emecheck_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_2emecheck_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_1ercheck_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_3emecheck_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_2emecheck_toggled                   (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_1ercheck_toggled                    (GtkToggleButton *togglebutton,
                                        gpointer         user_data);
