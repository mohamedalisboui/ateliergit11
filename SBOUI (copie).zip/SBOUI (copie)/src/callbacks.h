#include <gtk/gtk.h>

int o;


void
on_affi_nb_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actu_nb_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_rech_nb_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_Modif_nb_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);

void
on_ajout_nb_clicked                     (GtkWidget       *button,
                                        gpointer         user_data);
void
on_supp_nb_clicked                     (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_supp_tree_nb_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_checkbutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_checkbutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ok_nb_clicked                       (GtkWidget       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);





void
on_google_clicked                      (GtkButton       *button,
                                        gpointer         user_data);
